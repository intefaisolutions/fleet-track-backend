import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { ApiQuery } from '@nestjs/swagger';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { Public } from '../../decorators/public.decorator';
import { JwtAuthGuard } from '../../guards/jwt-auth.guard';
import { RolesGuard } from '../../guards/roles.guard';
import { SupportAdminPermissionsGuard } from '../../guards/support-admin-permissions.guard';
import { Roles } from '../../decorators/roles.decorator';
import { SupportAdminPermissions } from '../../decorators/support-admin-permissions.decorator';
import { ROLES } from '../../constants';
import { PlatformService } from '../services/platform.service';
import { UpdatePlatformSettingsDto } from '../dto/update-platform-settings.dto';
import { UpdatePlanPricingDto } from '../dto/update-plan-pricing.dto';
import { CreatePlanDto } from '../dto/create-plan.dto';
import { AddSupportAdminDto, UpdateSupportAdminPermissionsDto } from '../dto/support-admin.dto';

@ApiTags('Platform')
@Controller('platform')
export class PlatformController {
  constructor(private readonly platformService: PlatformService) {}

  @Public()
  @Get('plans')
  @ApiOperation({ summary: 'List subscription plans (public pricing)' })
  getPlans() {
    return this.platformService.getPlans();
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard, SupportAdminPermissionsGuard)
  @Get('pricing-overview')
  @Roles(ROLES.SUPER_ADMIN, ROLES.SUPPORT_ADMIN)
  @SupportAdminPermissions('settings:read')
  @ApiOperation({ summary: 'Plans, yearly discount, and subscription stats for pricing UI' })
  pricingOverview() {
    return this.platformService.getPricingOverview();
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard, SupportAdminPermissionsGuard)
  @Get('revenue-overview')
  @Roles(ROLES.SUPER_ADMIN, ROLES.SUPPORT_ADMIN)
  @SupportAdminPermissions('payments:read')
  @ApiOperation({ summary: 'Revenue overview — SRS 4.6 (monthly/yearly, by company, plan distribution)' })
  @ApiQuery({ name: 'month', required: false, type: Number })
  @ApiQuery({ name: 'year', required: false, type: Number })
  revenueOverview(
    @Query('month') month?: string,
    @Query('year') year?: string,
  ) {
    const m = month ? parseInt(month, 10) : undefined;
    const y = year ? parseInt(year, 10) : undefined;
    return this.platformService.getRevenueOverview(m, y);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard, SupportAdminPermissionsGuard)
  @Get('dashboard')
  @Roles(ROLES.SUPER_ADMIN, ROLES.SUPPORT_ADMIN)
  @SupportAdminPermissions('dashboard:read')
  @ApiOperation({ summary: 'Super Admin dashboard — SRS 4.1 (stats, revenue chart, payments, top companies)' })
  superAdminDashboard() {
    return this.platformService.getSuperAdminDashboard();
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get('owner-dashboard')
  @Roles(ROLES.SUPER_ADMIN)
  @ApiOperation({ summary: 'Alias for GET /platform/dashboard (legacy)' })
  ownerDashboard() {
    return this.platformService.getOwnerDashboard();
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Post('plans')
  @Roles(ROLES.SUPER_ADMIN)
  @ApiOperation({ summary: 'Create a custom subscription plan (Super Admin)' })
  createPlan(@Body() dto: CreatePlanDto) {
    return this.platformService.createPlan(dto);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Patch('plans/:planType')
  @Roles(ROLES.SUPER_ADMIN)
  updatePlan(@Param('planType') planType: string, @Body() dto: UpdatePlanPricingDto) {
    return this.platformService.updatePlanPricing(planType, dto);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard, SupportAdminPermissionsGuard)
  @Get('payment-settings')
  @Roles(ROLES.SUPER_ADMIN, ROLES.SUPPORT_ADMIN, ROLES.COMPANY_ADMIN, ROLES.VEHICLE_OWNER)
  @SupportAdminPermissions('payments:read', 'payments:write')
  getPaymentSettings() {
    return this.platformService.getPaymentSettings();
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Patch('payment-settings')
  @Roles(ROLES.SUPER_ADMIN)
  updatePaymentSettings(@Body() dto: UpdatePlatformSettingsDto) {
    return this.platformService.updatePaymentSettings(dto);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get('support-admins')
  @Roles(ROLES.SUPER_ADMIN)
  getSupportAdmins() {
    return this.platformService.getSupportAdmins();
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Post('support-admins')
  @Roles(ROLES.SUPER_ADMIN)
  addSupportAdmin(@Body() dto: AddSupportAdminDto) {
    return this.platformService.addSupportAdmin(dto);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Patch('support-admins/:email/permissions')
  @Roles(ROLES.SUPER_ADMIN)
  updateSupportAdminPermissions(
    @Param('email') email: string,
    @Body() dto: UpdateSupportAdminPermissionsDto,
  ) {
    return this.platformService.updateSupportAdminPermissions(
      decodeURIComponent(email),
      dto.permissions,
    );
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Delete('support-admins/:email')
  @Roles(ROLES.SUPER_ADMIN)
  removeSupportAdmin(@Param('email') email: string) {
    return this.platformService.removeSupportAdmin(decodeURIComponent(email));
  }
}
